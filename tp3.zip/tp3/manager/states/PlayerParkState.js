import * as THREE from "three";
import { GameState } from "../GameState.js";
/**
 * This class contains methods of  the game
 */
class PlayerParkState extends GameState {
    update(delta) {
        
    }
}

export { PlayerParkState };
