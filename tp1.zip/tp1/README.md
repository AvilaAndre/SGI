# SGI 2023/2024 - TP1

## Group: T05G07

| Name                           | Number    | E-Mail                   |
| ------------------------------ | --------- | ------------------------ |
| André Ismael Ferraz Ávila      | 202006767 | up202006767@edu.fe.up.pt |
| Maria Sofia B. P. C. Gonçalves | 202006927 | up202006927@edu.fe.up.pt |

---

## Project information  

-   (items describing main strong points)
-   Scene
    -   (Brief description of the created scene)
    -   (relative link to the scene)

---

## Issues/Problems

-   (items describing unimplemented features, bugs, problems, etc.)
